import SignOutButton from "../components/SignOutPage";

export default function Home() {
  return (
    <div className="p-6">
      <h1 className="text-2xl">Página de Admin (Acesso Restrito)</h1>
      <SignOutButton />
    </div>
  );
}
