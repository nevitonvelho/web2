export const metadata = {
  title: "Admin Application",
  description: "Example with NextAuth",
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
