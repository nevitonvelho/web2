import type { Metadata } from "next";
import localFont from "next/font/local";
import '@/app/globals.css';
import SignOutPage from "../components/SignOutPage";

const geistSans = localFont({
  src: "../fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "../fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export const metadata: Metadata = {
  title: "Portfólio de Engenharia de Software",
  description: "Sistema de portfólio dos alunos do Curso de Engenharia de Software",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt">
      <body 
      >
        <div className="grid lg:grid-cols-4 min-h-screen">
          {/* Side Menu */}
          <aside className="h-full lg:col-span-1 bg-white shadow-lg border">
            <div className="flex flex-col h-full">
              {/* Logo */}
              <div className="px-6 py-4 border-b flex items-center justify-center">
                <span className="block h-10 w-32  text-center text-gray-700 font-semibold text-xl">
                  Portfólio
                </span>
              </div>

            
              <nav className="flex-1 px-6 py-8 space-y-4">
                <ul className="space-y-2">
                  <li>
                    <a
                      href="#"
                      className="block px-4 py-2 text-gray-700 rounded-lg font-medium text-sm hover:bg-gray-100"
                    >
                      Geral
                    </a>
                  </li>
                  <li>
                    <details className="group">
                      <summary className="flex items-center justify-between px-4 py-2 cursor-pointer text-gray-700 rounded-lg hover:bg-gray-100">
                        <span className="font-medium text-sm">Alunos</span>
                        <svg
                          className="w-4 h-4 text-gray-500 group-open:rotate-180 transition-transform"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M5 15l7-7 7 7"
                          />
                        </svg>
                      </summary>
                      <ul className="mt-2 space-y-1 pl-6">
                        <li>
                          <a
                            href="#"
                            className="block px-4 py-2 text-gray-600 rounded-lg text-sm hover:bg-gray-100"
                          >
                            Lista de Alunos
                          </a>
                        </li>
                        <li>
                          <a
                            href="#"
                            className="block px-4 py-2 text-gray-600 rounded-lg text-sm hover:bg-gray-100"
                          >
                            Projetos
                          </a>
                        </li>
                      </ul>
                    </details>
                  </li>
                  <li>
                    <a
                      href="#"
                      className="block px-4 py-2 text-gray-700 rounded-lg font-medium text-sm hover:bg-gray-100"
                    >
                      Administração
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <main className="lg:col-span-3 p-6 bg-white">
            <div className="max-w-4xl mx-auto  p-6 ">
              {children}
            </div>
          </main>
        </div>
      </body>
    </html>
  );
}
