import { GET, POST } from "@/auth";

export { GET, POST };
